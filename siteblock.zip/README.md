# siteblock

```
zip -r siteblock.zip . -x '_.git_' '_node_modules_' '\*.DS_Store'
```
